export interface Product {
  id: string;
  title: string;
  subtitle: string;
  price: number;
  description: string;
  material: string;
  origin: string;
  sizes: string[];
  categories: string[];
  mainImage: string;
  galleryImages?: string[];
  sustainability: string;
  careInstructions: string;
  color: string;
  fabric: string;
}

export interface Category {
  name: string;
  displayName: string;
  thumbnailImage: string;
}

export interface CartItem {
  product: Product;
  selectedSize: string;
  quantity: number;
}

export interface WishlistItem {
  product: Product;
  dateAdded: string;
}
