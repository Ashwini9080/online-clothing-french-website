import React from "react";
import { Menu, ShoppingBag } from "lucide-react";

interface NavbarProps {
  onCartToggle: () => void;
  cartCount: number;
  onNavigate: (view: "home" | "shop" | "wishlist" | "profile") => void;
  onMenuToggle: () => void;
}

export default function Navbar({
  onCartToggle,
  cartCount,
  onNavigate,
  onMenuToggle,
}: NavbarProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-40 glass-nav h-20 border-b border-outline-variant/5">
      <div className="max-w-7xl mx-auto px-6 h-full flex items-center justify-between">
        {/* Menu Toggle */}
        <div className="flex-1 flex justify-start">
          <button
            onClick={onMenuToggle}
            className="p-2.5 -ml-2.5 text-on-surface hover:opacity-75 transition-opacity cursor-pointer flex items-center justify-center rounded-full"
            aria-label="Toggle Navigation Drawer"
            id="nav-menu-toggle"
          >
            <Menu className="w-5 h-5 stroke-[1.5]" />
          </button>
        </div>

        {/* Brand Name Title */}
        <div className="flex-1 flex justify-center">
          <h1
            onClick={() => onNavigate("home")}
            className="font-headline text-xl sm:text-2xl tracking-[0.25em] font-bold text-primary cursor-pointer hover:opacity-85 transition-opacity select-none"
            id="brand-title"
          >
            LUMIERE
          </h1>
        </div>

        {/* Shopping Bag Button */}
        <div className="flex-1 flex justify-end">
          <button
            onClick={onCartToggle}
            className="p-2.5 -mr-2.5 relative text-on-surface hover:opacity-75 transition-opacity cursor-pointer flex items-center justify-center rounded-full"
            aria-label="Open Shopping Bag"
            id="nav-cart-toggle"
          >
            <ShoppingBag className="w-5 h-5 stroke-[1.5]" />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-primary text-on-primary rounded-full text-[9px] font-label font-bold flex items-center justify-center shadow-md border border-surface animate-pulse">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
