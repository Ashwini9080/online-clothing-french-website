import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Heart, ChevronDown, Check, Ruler, ShoppingBag, ArrowLeft } from "lucide-react";
import { Product } from "../types";
import { products } from "../data";

interface ProductDetailViewProps {
  productId: string;
  onNavigateToProduct: (productId: string) => void;
  onNavigateBack: () => void;
  onAddToBag: (product: Product, size: string) => void;
  wishlistIds: string[];
  onToggleWishlist: (product: Product) => void;
}

export default function ProductDetailView({
  productId,
  onNavigateToProduct,
  onNavigateBack,
  onAddToBag,
  wishlistIds,
  onToggleWishlist,
}: ProductDetailViewProps) {
  const product = products.find((p) => p.id === productId) || products[0];

  const [selectedSize, setSelectedSize] = useState<string>("");
  const [activeAccordion, setActiveAccordion] = useState<string | null>(null);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
  const [successToast, setSuccessToast] = useState(false);

  // Default select first available size or S
  useEffect(() => {
    if (product.sizes.length > 0) {
      if (product.sizes.includes("S")) {
        setSelectedSize("S");
      } else {
        setSelectedSize(product.sizes[0]);
      }
    }
    // Scroll to top on load
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [product]);

  const isFav = wishlistIds.includes(product.id);

  // Get related products (Complete the Look)
  const relatedProducts = products.filter((p) => p.id !== product.id).slice(0, 3);

  const handleAddToBag = () => {
    if (!selectedSize) return;
    onAddToBag(product, selectedSize);
    setSuccessToast(true);
    setTimeout(() => setSuccessToast(false), 3000);
  };

  const toggleAccordion = (section: string) => {
    if (activeAccordion === section) {
      setActiveAccordion(null);
    } else {
      setActiveAccordion(section);
    }
  };

  // Fallback for sub gallery images if not defined
  const gallery = product.galleryImages || [
    product.mainImage,
    product.mainImage,
    product.mainImage,
    product.mainImage,
  ];

  return (
    <div className="pt-6 pb-24 font-body max-w-7xl mx-auto px-6" id="product-detail-view">
      {/* Back button */}
      <button
        onClick={onNavigateBack}
        className="mb-8 flex items-center gap-2 text-xs font-label uppercase tracking-widest text-outline hover:text-primary transition-colors cursor-pointer select-none"
        id="detail-back-btn"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>BACK TO ANTHOLOGY</span>
      </button>

      {/* Main Grid split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-x-12 gap-y-16">
        
        {/* LEFT COLUMN: Product Gallery Asymmetrical Grid */}
        <div className="lg:col-span-7 space-y-12 select-none">
          {/* Main big tall image */}
          <div className="relative aspect-[3/4] overflow-hidden bg-surface-dim border border-outline-variant/10">
            <img
              className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700 ease-in-out"
              src={gallery[0]}
              alt={`${product.title} main shot`}
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Dual square thumbnail rows */}
          <div className="grid grid-cols-2 gap-8">
            <div className="aspect-[4/5] overflow-hidden bg-surface-dim border border-outline-variant/10">
              <img
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
                src={gallery[1]}
                alt={`${product.title} detail texture`}
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="aspect-[4/5] overflow-hidden bg-surface-dim border border-outline-variant/10 mt-12">
              <img
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
                src={gallery[2]}
                alt={`${product.title} back detail`}
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Landscape wide bottom lifestyle image */}
          <div className="aspect-[16/9] overflow-hidden bg-surface-dim border border-outline-variant/10">
            <img
              className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
              src={gallery[3] || gallery[0]}
              alt={`${product.title} lifestyle look`}
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* RIGHT COLUMN: Sticky Info & Actions Panel */}
        <div className="lg:col-span-5 lg:sticky lg:top-32 self-start flex flex-col space-y-10">
          
          {/* Title & Collection & Wishlist */}
          <div className="border-b border-outline-variant/10 pb-6">
            <div className="flex justify-between items-start mb-4 select-none">
              <p className="font-label text-xs tracking-[0.25em] text-outline uppercase font-medium">
                {product.subtitle}
              </p>
              <button
                onClick={() => onToggleWishlist(product)}
                className="text-on-surface hover:text-error transition-colors cursor-pointer"
                aria-label={isFav ? "Remove from wishlist" : "Add to wishlist"}
                id="detail-wishlist-toggle"
              >
                <Heart
                  className={`w-5 h-5 transition-colors ${
                    isFav ? "fill-error text-error" : "text-primary"
                  }`}
                />
              </button>
            </div>
            <h2 className="font-headline text-4xl md:text-5xl mb-4 leading-tight font-light select-none">
              {product.title}
            </h2>
            <p className="font-body text-xl tracking-tight text-primary font-bold">
              ${product.price.toLocaleString()}.00
            </p>
          </div>

          {/* Description & Technical Table */}
          <div className="space-y-6">
            <p className="font-body text-sm leading-relaxed text-on-surface-variant max-w-md select-none">
              {product.description}
            </p>

            <div className="pt-4 flex flex-col space-y-2 select-none">
              <div className="flex justify-between items-center py-4 border-b border-outline-variant/15">
                <span className="font-label text-[10px] uppercase tracking-[0.15em] text-outline font-medium">
                  Material
                </span>
                <span className="font-body text-sm italic font-medium">{product.material}</span>
              </div>
              <div className="flex justify-between items-center py-4 border-b border-outline-variant/15">
                <span className="font-label text-[10px] uppercase tracking-[0.15em] text-outline font-medium">
                  Origin
                </span>
                <span className="font-body text-sm font-medium">{product.origin}</span>
              </div>
            </div>
          </div>

          {/* Size Selector */}
          <div className="space-y-4">
            <div className="flex justify-between items-end select-none">
              <label className="font-label text-[10px] uppercase tracking-[0.15em] text-outline font-medium">
                Select Size
              </label>
              <button
                onClick={() => setIsSizeGuideOpen(true)}
                className="font-label text-[10px] underline underline-offset-4 uppercase tracking-[0.1em] text-outline hover:text-primary transition-colors cursor-pointer flex items-center gap-1.5"
                id="size-guide-trigger"
              >
                <Ruler className="w-3.5 h-3.5" />
                <span>Size Guide</span>
              </button>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {product.sizes.map((sz) => (
                <button
                  key={sz}
                  onClick={() => setSelectedSize(sz)}
                  className={`py-4 text-xs font-label uppercase tracking-widest transition-all cursor-pointer border ${
                    selectedSize === sz
                      ? "bg-primary text-on-primary border-primary font-bold shadow-sm"
                      : "bg-surface-container-lowest text-outline border-outline-variant/20 hover:border-outline hover:text-primary"
                  }`}
                  id={`detail-size-${sz}`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          {/* Actions: Add to bag */}
          <div className="space-y-4 pt-4">
            <button
              onClick={handleAddToBag}
              disabled={!selectedSize}
              className="w-full bg-primary text-on-primary py-5 px-8 font-label text-xs uppercase tracking-[0.25em] hover:bg-primary-fixed active:scale-[0.98] transition-all flex items-center justify-center gap-3 cursor-pointer"
              id="add-to-bag-btn"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>ADD TO BAG</span>
            </button>
            <p className="text-center font-label text-[10px] text-outline tracking-wider select-none">
              Complimentary carbon-neutral express shipping on all curated orders.
            </p>
          </div>

          {/* Expandable Accordions */}
          <div className="pt-6 border-t border-outline-variant/15 space-y-2 select-none">
            {/* Sustainability Accordion */}
            <div className="border-b border-outline-variant/15">
              <button
                onClick={() => toggleAccordion("sustainability")}
                className="w-full py-4 flex justify-between items-center text-left hover:text-primary transition-colors cursor-pointer"
                id="accordion-trigger-sustainability"
              >
                <span className="font-label text-[10px] uppercase tracking-[0.15em] font-medium">
                  Sustainability
                </span>
                <ChevronDown
                  className={`w-4 h-4 text-outline transition-transform duration-300 ${
                    activeAccordion === "sustainability" ? "rotate-180" : ""
                  }`}
                />
              </button>
              <AnimatePresence initial={false}>
                {activeAccordion === "sustainability" && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <p className="pb-6 text-xs text-outline leading-relaxed">
                      {product.sustainability}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Care Instructions Accordion */}
            <div className="border-b border-outline-variant/15">
              <button
                onClick={() => toggleAccordion("care")}
                className="w-full py-4 flex justify-between items-center text-left hover:text-primary transition-colors cursor-pointer"
                id="accordion-trigger-care"
              >
                <span className="font-label text-[10px] uppercase tracking-[0.15em] font-medium">
                  Care Instructions
                </span>
                <ChevronDown
                  className={`w-4 h-4 text-outline transition-transform duration-300 ${
                    activeAccordion === "care" ? "rotate-180" : ""
                  }`}
                />
              </button>
              <AnimatePresence initial={false}>
                {activeAccordion === "care" && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <p className="pb-6 text-xs text-outline leading-relaxed">
                      {product.careInstructions}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      {/* Related items tray */}
      <section className="mt-40 border-t border-outline-variant/15 pt-20">
        <h3 className="font-headline text-3xl mb-16 text-center italic select-none">
          Complete the Look
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
          {relatedProducts.map((p, idx) => (
            <div
              key={p.id}
              onClick={() => onNavigateToProduct(p.id)}
              className={`space-y-4 group cursor-pointer ${
                idx === 2 ? "hidden md:block" : ""
              }`}
              id={`related-item-card-${p.id}`}
            >
              <div className="aspect-[3/4] overflow-hidden bg-surface-container border border-outline-variant/10 select-none">
                <img
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 grayscale group-hover:grayscale-0"
                  src={p.mainImage}
                  alt={p.title}
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="space-y-1 select-none">
                <h4 className="font-label text-[11px] uppercase tracking-widest font-bold group-hover:underline">
                  {p.title}
                </h4>
                <p className="font-body text-sm text-outline">${p.price.toLocaleString()}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SIZE GUIDE MODAL */}
      <AnimatePresence>
        {isSizeGuideOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSizeGuideOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 cursor-pointer"
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-11/12 max-w-md bg-surface z-50 p-8 shadow-2xl border border-outline-variant/20 font-body select-none"
              id="size-guide-modal"
            >
              <h3 className="font-headline text-lg tracking-widest uppercase mb-4 border-b border-outline-variant/15 pb-4">
                SIZE GUIDE (CM)
              </h3>
              <table className="w-full text-xs font-label uppercase tracking-wider mb-6">
                <thead>
                  <tr className="border-b border-outline-variant/30 text-outline">
                    <th className="text-left py-2">Size</th>
                    <th className="text-center py-2">Bust</th>
                    <th className="text-center py-2">Waist</th>
                    <th className="text-center py-2">Hips</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-outline-variant/10">
                  <tr>
                    <td className="py-3 font-bold">XS</td>
                    <td className="text-center py-3">80 - 84</td>
                    <td className="text-center py-3">60 - 64</td>
                    <td className="text-center py-3">86 - 90</td>
                  </tr>
                  <tr>
                    <td className="py-3 font-bold">S</td>
                    <td className="text-center py-3">84 - 88</td>
                    <td className="text-center py-3">64 - 68</td>
                    <td className="text-center py-3">90 - 94</td>
                  </tr>
                  <tr>
                    <td className="py-3 font-bold">M</td>
                    <td className="text-center py-3">88 - 92</td>
                    <td className="text-center py-3">68 - 72</td>
                    <td className="text-center py-3">94 - 98</td>
                  </tr>
                  <tr>
                    <td className="py-3 font-bold">L</td>
                    <td className="text-center py-3">92 - 96</td>
                    <td className="text-center py-3">72 - 76</td>
                    <td className="text-center py-3">98 - 102</td>
                  </tr>
                </tbody>
              </table>
              <button
                onClick={() => setIsSizeGuideOpen(false)}
                className="w-full bg-primary text-on-primary py-4 font-label text-xs uppercase tracking-widest hover:bg-primary-fixed transition-colors cursor-pointer"
              >
                Close Guide
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* TOAST NOTIFICATION */}
      <AnimatePresence>
        {successToast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-24 left-6 right-6 sm:left-auto sm:right-6 bg-primary text-on-primary py-4 px-6 shadow-2xl z-50 flex items-center gap-3 font-label text-xs tracking-widest uppercase border border-outline-variant/10 select-none"
            id="detail-success-toast"
          >
            <Check className="w-4 h-4 text-green-400" />
            <span>{product.title} (SIZE {selectedSize}) added to bag.</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
