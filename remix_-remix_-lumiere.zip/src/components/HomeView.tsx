import React from "react";
import { motion } from "motion/react";
import { ArrowRight } from "lucide-react";
import { Category } from "../types";
import { categories } from "../data";

interface HomeViewProps {
  onNavigateToShop: (categoryFilter?: string) => void;
  onNavigateToProduct: (productId: string) => void;
}

export default function HomeView({
  onNavigateToShop,
  onNavigateToProduct,
}: HomeViewProps) {
  return (
    <div className="space-y-24 pb-16 font-body" id="home-view">
      {/* Hero Section */}
      <section className="relative h-[85vh] w-full overflow-hidden">
        {/* Background Editorial Image */}
        <img
          alt="Seasonal Editorial Collection"
          className="w-full h-full object-cover select-none"
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuDhsDE-a4ChHKniOaaSNcJGPUiAdooTqSGn6fs5OmpH-pIThHIJWCHdhMMsW3NDq6O1MsCGlsibX93KZfnQmsKII5u1P6V1rGrn0cbJWU3bzLFDYaEkDTzK61-AtJhX0daktTP2p3VEEGsNsGI1jL0GTXj_Oo6g_Ic5V7Z8dPfTtmn8mbTQ60ezZUmB5bWeNAhKioDnbb2BOvxuHdMPIbymFzKG1Ll1gUbRL1p5QS03fyMngE3KuDmTpGXK9wbwSXQ9ieLQzbKN4vg"
          referrerPolicy="no-referrer"
        />
        {/* Dark subtle gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/20" />

        {/* Content Box */}
        <div className="absolute inset-0 flex flex-col items-center justify-end pb-24 text-center px-6">
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="font-headline text-5xl md:text-7xl text-on-primary-fixed mb-8 leading-tight max-w-2xl select-none"
          >
            The Winter <br /> Anthology
          </motion.h2>
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            onClick={() => onNavigateToShop("ALL")}
            className="bg-primary text-on-primary px-10 py-5 text-xs tracking-[0.25em] font-label hover:bg-primary-container hover:scale-105 active:scale-95 transition-all duration-300 cursor-pointer"
            id="hero-cta-btn"
          >
            SHOP THE LOOK
          </motion.button>
        </div>
      </section>

      {/* Category Carousel */}
      <section className="px-6 max-w-7xl mx-auto">
        <div className="flex items-end justify-between mb-8 border-b border-outline-variant/10 pb-4">
          <h3 className="font-headline text-2xl tracking-wide">Collections</h3>
          <button
            onClick={() => onNavigateToShop("ALL")}
            className="font-label text-xs tracking-[0.2em] font-bold border-b border-primary pb-1 hover:opacity-75 transition-opacity cursor-pointer"
            id="view-all-collections"
          >
            VIEW ALL
          </button>
        </div>

        {/* Categories Grid/Flex List */}
        <div className="flex overflow-x-auto hide-scrollbar gap-8 sm:gap-12 pb-4 scroll-smooth">
          {categories.map((cat, idx) => (
            <motion.div
              key={cat.name}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.1, duration: 0.5 }}
              onClick={() => onNavigateToShop(cat.name)}
              className="flex flex-col items-center flex-shrink-0 cursor-pointer group select-none"
              id={`collection-circle-${cat.name.toLowerCase()}`}
            >
              {/* Outer circular border decoration */}
              <div className="w-24 h-24 rounded-full overflow-hidden border border-outline-variant/30 p-1 mb-4 group-hover:border-primary transition-colors duration-300">
                <img
                  alt={cat.displayName}
                  className="w-full h-full object-cover rounded-full grayscale group-hover:grayscale-0 transition-all duration-500 group-hover:scale-105"
                  src={cat.thumbnailImage}
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="font-label text-xs tracking-widest uppercase text-outline group-hover:text-primary transition-colors">
                {cat.displayName}
              </span>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Featured Editorial Grid */}
      <section className="px-6 max-w-7xl mx-auto grid grid-cols-12 gap-y-16 md:gap-x-12">
        <div className="col-span-12 mb-4 border-b border-outline-variant/10 pb-4">
          <h3 className="font-label text-[10px] tracking-[0.45em] text-outline uppercase font-medium">
            Issue No. 04 — Essentialism
          </h3>
        </div>

        {/* Left Column: Monolith Coat (Trench) */}
        <div className="col-span-12 md:col-span-7 pr-0 md:pr-4 group">
          <div
            onClick={() => onNavigateToProduct("the-archival-trench")}
            className="bg-surface-container-lowest h-[400px] sm:h-[480px] w-full overflow-hidden cursor-pointer relative"
          >
            <img
              alt="Editorial Monolith Coat"
              className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-105"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDjT8Yi2sesfMugzSPwC2ObE0tGGPcdSRc-qH5uSTeIwN9n7fN-C9Kww-kbi0cAEK0Swc2vufkOyFs800ecT0kAQcD5_r_7W-076YQZ-Cp6fMb9So3fOpUkq_Sc1445QxNR6oCn6V6yf5ZOorFaQjDvXeCIiQxuzWFVYilA-ge7QA2b1-M7eARcfDTGnngddVpTQPuG-STk8NvmpQi57GNLAgNAnZkFrgX8UOzS9ljZOKlOFbI264Jf7yf-jXE2fTDNjN5Hpi4t98k"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-black/5 group-hover:bg-transparent transition-all duration-500" />
          </div>
          <div className="mt-6 space-y-2">
            <h4
              onClick={() => onNavigateToProduct("the-archival-trench")}
              className="font-headline text-2xl font-medium cursor-pointer hover:underline inline-block leading-tight"
            >
              The Monolith Coat
            </h4>
            <p className="font-body text-sm text-on-surface-variant leading-relaxed max-w-xl">
              Structural integrity meets raw silk. A study in architectural volume for the modern nomad. Fully customized detailing with virgin Italian wool canvas.
            </p>
          </div>
        </div>

        {/* Right Column: Discover Offset Detail */}
        <div className="col-span-12 md:col-span-4 md:col-start-9 pt-0 md:pt-20 group">
          <div
            onClick={() => onNavigateToShop("ALL")}
            className="bg-surface-container-lowest h-[300px] sm:h-[360px] w-full overflow-hidden cursor-pointer relative"
          >
            <img
              alt="Editorial Accent"
              className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-105"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuB3qwjL2PuB2ZO_9Bh-m0J3PSRBVhmxsw-Xlhfzb57zurw9NZbsHXwrpaDtxPzij28CCUTaF7j2hIj-tScbOY9oSZRoKo47Go6clWeidbYUf7Tu5g3_lCd-mKioWqdZ2oUkiSVX1RZTxl9WKj-AJqmIWwLTCv9n5g_Ypzr10XitLOwAu-ugwJ_pZvrQqkamydJitPn5ZHbPRNOKCroUI9jsguKBrrnpZoebRRhjHpM7NY3MLTRDORDmEyZO-SG9I-YaHcsr-zga17c"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-black/5 group-hover:bg-transparent transition-all duration-500" />
          </div>
          <div className="mt-6">
            <button
              onClick={() => onNavigateToShop("ALL")}
              className="font-label text-[10px] tracking-[0.2em] font-bold text-primary border-b border-primary pb-1 cursor-pointer hover:opacity-75 transition-opacity flex items-center gap-2"
              id="editorial-discover-link"
            >
              <span>DISCOVER</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* Quote / Brand Statement */}
      <section className="my-32 px-6 text-center max-w-3xl mx-auto">
        <p className="font-headline italic text-2xl leading-relaxed text-on-surface/80">
          "Fashion is the most powerful art we have. It is how we present our souls to the world."
        </p>
        <div className="h-16 w-px bg-outline-variant mx-auto mt-12 opacity-40" />
      </section>
    </div>
  );
}
