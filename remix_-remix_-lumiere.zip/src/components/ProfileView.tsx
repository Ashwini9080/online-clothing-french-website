import React from "react";
import { motion } from "motion/react";
import { User, ShieldCheck, Box, History, Calendar, Heart } from "lucide-react";

interface ProfileViewProps {
  userEmail: string;
}

export default function ProfileView({ userEmail }: ProfileViewProps) {
  // Derive name nicely from email or default
  const userName = "Ashwini Gupta";

  return (
    <div className="pb-24 font-body max-w-3xl mx-auto px-6" id="profile-view">
      {/* Header section */}
      <header className="mb-12 pt-6 select-none">
        <p className="font-label text-[10px] uppercase tracking-[0.25em] text-outline mb-4">
          Client Workspace
        </p>
        <h2 className="font-headline text-4xl sm:text-6xl italic leading-tight font-light">
          My Account
        </h2>
      </header>

      <div className="space-y-12">
        {/* User Card */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-surface-container-low p-8 border border-outline-variant/10 flex flex-col md:flex-row md:items-center justify-between gap-6"
        >
          <div className="flex items-center gap-6">
            <div className="w-16 h-16 rounded-full bg-primary text-on-primary flex items-center justify-center font-headline text-2xl font-bold select-none shadow-md">
              A
            </div>
            <div>
              <h3 className="font-headline text-2xl tracking-wide font-medium">{userName}</h3>
              <p className="font-label text-xs text-outline mt-1">{userEmail}</p>
              <div className="mt-3 inline-flex items-center gap-1.5 px-2.5 py-1 bg-primary text-on-primary text-[9px] font-label uppercase tracking-widest font-bold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>LUMIERE Privé Member</span>
              </div>
            </div>
          </div>

          <div className="text-left md:text-right select-none">
            <p className="font-label text-[10px] text-outline uppercase tracking-wider">LUMIERE WALLET</p>
            <p className="font-body text-xl font-bold text-primary mt-1">$450.00 Credits</p>
          </div>
        </motion.div>

        {/* Member Benefits */}
        <div className="space-y-4">
          <h4 className="font-headline text-xl italic select-none">Privileges & Services</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-6 bg-surface-container-lowest border border-outline-variant/10 space-y-2">
              <Calendar className="w-5 h-5 text-outline" />
              <h5 className="font-label text-xs uppercase tracking-widest font-bold text-primary">Private Styling</h5>
              <p className="text-xs text-outline leading-relaxed">
                Complementary 1-on-1 virtual design styling sessions with our Milanese team.
              </p>
            </div>
            <div className="p-6 bg-surface-container-lowest border border-outline-variant/10 space-y-2">
              <Box className="w-5 h-5 text-outline" />
              <h5 className="font-label text-xs uppercase tracking-widest font-bold text-primary">Eco Delivery</h5>
              <p className="text-xs text-outline leading-relaxed">
                Sustainable, reusable luxury packaging and zero-carbon priority shipping.
              </p>
            </div>
          </div>
        </div>

        {/* Purchase History list */}
        <div className="space-y-6">
          <h4 className="font-headline text-xl italic select-none">Order Anthology</h4>
          <div className="divide-y divide-outline-variant/10">
            {/* Order Item 1 */}
            <div className="py-6 flex justify-between items-center gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-3">
                  <span className="font-label text-xs uppercase tracking-widest font-bold text-primary">
                    Order #LM-2049
                  </span>
                  <span className="px-2 py-0.5 bg-green-100 text-green-800 text-[9px] font-label uppercase tracking-widest font-bold">
                    Delivered
                  </span>
                </div>
                <p className="text-xs text-outline font-medium">Shipped October 12, 2026 via Luxury Post</p>
                <p className="text-xs font-label uppercase tracking-wider text-outline pt-2">
                  1x Sculpted Silk Gown (Size S)
                </p>
              </div>
              <div className="text-right">
                <span className="font-body text-base font-bold text-primary">$2,450.00</span>
              </div>
            </div>

            {/* Order Item 2 */}
            <div className="py-6 flex justify-between items-center gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-3">
                  <span className="font-label text-xs uppercase tracking-widest font-bold text-primary">
                    Order #LM-1941
                  </span>
                  <span className="px-2 py-0.5 bg-green-100 text-green-800 text-[9px] font-label uppercase tracking-widest font-bold">
                    Delivered
                  </span>
                </div>
                <p className="text-xs text-outline font-medium">Shipped June 4, 2026 via Eco Logistics</p>
                <p className="text-xs font-label uppercase tracking-wider text-outline pt-2">
                  1x The Void Trousers (Size M)
                </p>
              </div>
              <div className="text-right">
                <span className="font-body text-base font-bold text-primary">$550.00</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
