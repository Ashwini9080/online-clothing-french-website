import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Minus, Plus, Trash2, ArrowRight, ShoppingBag } from "lucide-react";
import { CartItem } from "../types";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, size: string, change: number) => void;
  onRemoveItem: (productId: string, size: string) => void;
  onCheckout: () => void;
  onNavigateToProduct: (productId: string) => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
  onNavigateToProduct,
}: CartDrawerProps) {
  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 cursor-pointer"
            id="cart-backdrop"
          />

          {/* Drawer Panel */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 bottom-0 w-full sm:w-[480px] bg-surface z-50 shadow-2xl flex flex-col font-body border-l border-outline-variant/10"
            id="cart-panel"
          >
            {/* Header */}
            <div className="p-6 border-b border-outline-variant/20 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <ShoppingBag className="w-5 h-5 text-primary" />
                <h2 className="font-headline text-lg tracking-widest uppercase">
                  Shopping Bag ({cartItems.reduce((acc, curr) => acc + curr.quantity, 0)})
                </h2>
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-surface-container-high transition-colors text-outline hover:text-primary cursor-pointer"
                id="close-cart-btn"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 hide-scrollbar">
              {cartItems.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-20">
                  <div className="w-16 h-16 rounded-full bg-surface-container-low flex items-center justify-center text-outline/55">
                    <ShoppingBag className="w-8 h-8" />
                  </div>
                  <h3 className="font-headline text-xl italic">Your bag is empty</h3>
                  <p className="text-xs text-outline tracking-wider max-w-[280px]">
                    Explore our seasonal lookbook and discover custom garments designed for quiet elegance.
                  </p>
                  <button
                    onClick={onClose}
                    className="mt-4 px-8 py-4 bg-primary text-on-primary font-label text-xs uppercase tracking-widest hover:bg-primary-fixed transition-colors cursor-pointer"
                    id="cart-shop-now-btn"
                  >
                    Start Exploring
                  </button>
                </div>
              ) : (
                cartItems.map((item, index) => (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    key={`${item.product.id}-${item.selectedSize}`}
                    className="flex gap-4 p-4 bg-surface-container-lowest border border-outline-variant/10 hover:border-outline-variant/30 transition-all group"
                  >
                    {/* Item Image */}
                    <div
                      onClick={() => {
                        onNavigateToProduct(item.product.id);
                        onClose();
                      }}
                      className="w-20 h-24 bg-surface-dim overflow-hidden flex-shrink-0 cursor-pointer"
                    >
                      <img
                        src={item.product.mainImage}
                        alt={item.product.title}
                        className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    {/* Item Information */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start">
                          <h4
                            onClick={() => {
                              onNavigateToProduct(item.product.id);
                              onClose();
                            }}
                            className="font-headline text-sm font-bold hover:underline cursor-pointer leading-tight"
                          >
                            {item.product.title}
                          </h4>
                          <span className="font-body text-sm font-medium">
                            ${(item.product.price * item.quantity).toLocaleString()}
                          </span>
                        </div>
                        <p className="font-label text-[10px] text-outline uppercase tracking-widest mt-1">
                          {item.product.subtitle}
                        </p>
                        <span className="inline-block mt-2 px-2 py-0.5 bg-surface-container text-[10px] font-label uppercase tracking-wider text-on-surface-variant font-medium">
                          Size: {item.selectedSize}
                        </span>
                      </div>

                      {/* Quantity Controls & Remove */}
                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center border border-outline-variant/30 bg-surface">
                          <button
                            onClick={() =>
                              onUpdateQuantity(item.product.id, item.selectedSize, -1)
                            }
                            className="p-1.5 text-outline hover:text-primary transition-colors cursor-pointer"
                            id={`qty-minus-${item.product.id}`}
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="px-3 text-xs font-label font-bold text-center select-none">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() =>
                              onUpdateQuantity(item.product.id, item.selectedSize, 1)
                            }
                            className="p-1.5 text-outline hover:text-primary transition-colors cursor-pointer"
                            id={`qty-plus-${item.product.id}`}
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.product.id, item.selectedSize)}
                          className="p-1 text-outline hover:text-error transition-colors cursor-pointer"
                          id={`remove-item-${item.product.id}`}
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>

            {/* Footer Summary */}
            {cartItems.length > 0 && (
              <div className="p-6 bg-surface-container-low border-t border-outline-variant/20 space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-label uppercase tracking-wider text-outline">
                    <span>Shipping</span>
                    <span className="text-primary font-medium tracking-normal">Complimentary</span>
                  </div>
                  <div className="flex justify-between text-xs font-label uppercase tracking-wider text-outline">
                    <span>Taxes</span>
                    <span className="text-primary tracking-normal">Calculated at Checkout</span>
                  </div>
                  <div className="flex justify-between pt-4 border-t border-outline-variant/20">
                    <span className="font-headline text-base tracking-widest uppercase">Estimated Total</span>
                    <span className="font-body text-xl font-bold">${subtotal.toLocaleString()}</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <button
                    onClick={onCheckout}
                    className="w-full bg-primary text-on-primary py-5 px-6 font-label text-xs uppercase tracking-[0.25em] hover:bg-primary-fixed transition-colors flex items-center justify-center gap-2 cursor-pointer group"
                    id="checkout-btn"
                  >
                    <span>Proceed to Checkout</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                  <p className="text-center font-label text-[10px] text-outline tracking-wider">
                    Free express carbon-neutral shipping on all curated orders.
                  </p>
                </div>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
