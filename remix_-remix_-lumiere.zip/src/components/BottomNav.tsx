import React from "react";
import { Home, Store, Heart, User } from "lucide-react";

interface BottomNavProps {
  currentView: "home" | "shop" | "wishlist" | "profile" | "detail";
  onNavigate: (view: "home" | "shop" | "wishlist" | "profile") => void;
  wishlistCount: number;
}

export default function BottomNav({
  currentView,
  onNavigate,
  wishlistCount,
}: BottomNavProps) {
  // Map detail view back to shop or active tab highlights
  const activeView = currentView === "detail" ? "shop" : currentView;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 glass-nav h-20 border-t border-outline-variant/10 px-6">
      <div className="max-w-md mx-auto h-full grid grid-cols-4">
        {/* Home */}
        <button
          onClick={() => onNavigate("home")}
          className={`flex flex-col items-center justify-center space-y-1 cursor-pointer transition-all ${
            activeView === "home"
              ? "text-primary opacity-100"
              : "text-outline hover:text-primary opacity-55 hover:opacity-100"
          }`}
          id="btn-nav-home"
        >
          <Home className={`w-5 h-5 ${activeView === "home" ? "fill-current stroke-[2]" : "stroke-[1.5]"}`} />
          <span className="font-label text-[10px] mt-1 tracking-wider">Home</span>
        </button>

        {/* Shop */}
        <button
          onClick={() => onNavigate("shop")}
          className={`flex flex-col items-center justify-center space-y-1 cursor-pointer transition-all ${
            activeView === "shop"
              ? "text-primary opacity-100"
              : "text-outline hover:text-primary opacity-55 hover:opacity-100"
          }`}
          id="btn-nav-shop"
        >
          <Store className={`w-5 h-5 ${activeView === "shop" ? "fill-current stroke-[2]" : "stroke-[1.5]"}`} />
          <span className="font-label text-[10px] mt-1 tracking-wider">Shop</span>
        </button>

        {/* Wishlist */}
        <button
          onClick={() => onNavigate("wishlist")}
          className={`flex flex-col items-center justify-center space-y-1 cursor-pointer transition-all relative ${
            activeView === "wishlist"
              ? "text-primary opacity-100"
              : "text-outline hover:text-primary opacity-55 hover:opacity-100"
          }`}
          id="btn-nav-wishlist"
        >
          <Heart className={`w-5 h-5 ${activeView === "wishlist" ? "fill-current stroke-[2]" : "stroke-[1.5]"}`} />
          <span className="font-label text-[10px] mt-1 tracking-wider">Wishlist</span>
          {wishlistCount > 0 && (
            <span className="absolute top-2 right-6 min-w-4 h-4 px-1 rounded-full bg-primary text-on-primary text-[8px] font-bold flex items-center justify-center shadow-sm">
              {wishlistCount}
            </span>
          )}
        </button>

        {/* Profile */}
        <button
          onClick={() => onNavigate("profile")}
          className={`flex flex-col items-center justify-center space-y-1 cursor-pointer transition-all ${
            activeView === "profile"
              ? "text-primary opacity-100"
              : "text-outline hover:text-primary opacity-55 hover:opacity-100"
          }`}
          id="btn-nav-profile"
        >
          <User className={`w-5 h-5 ${activeView === "profile" ? "fill-current stroke-[2]" : "stroke-[1.5]"}`} />
          <span className="font-label text-[10px] mt-1 tracking-wider">Profile</span>
        </button>
      </div>
    </nav>
  );
}
