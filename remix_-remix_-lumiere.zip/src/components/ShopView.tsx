import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Heart, Search, Filter, SlidersHorizontal, Check, RefreshCw } from "lucide-react";
import { Product } from "../types";
import { products } from "../data";

interface ShopViewProps {
  onNavigateToProduct: (productId: string) => void;
  wishlistIds: string[];
  onToggleWishlist: (product: Product) => void;
  selectedCategory: string;
  onSetCategory: (category: string) => void;
  filterSize: string;
  onSetSize: (size: string) => void;
  filterColor: string;
  onSetColor: (color: string) => void;
  filterFabric: string;
  onSetFabric: (fabric: string) => void;
}

export default function ShopView({
  onNavigateToProduct,
  wishlistIds,
  onToggleWishlist,
  selectedCategory,
  onSetCategory,
  filterSize,
  onSetSize,
  filterColor,
  onSetColor,
  filterFabric,
  onSetFabric,
}: ShopViewProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [visibleCount, setVisibleCount] = useState(6);
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);

  // Filter Dropdowns
  const [activeDropdown, setActiveDropdown] = useState<"size" | "color" | "fabric" | null>(null);

  // Available Filter Options
  const sizesList = ["ALL", "XS", "S", "M", "L"];
  const colorsList = ["ALL", "MONO", "GOLD"];
  const fabricsList = ["ALL", "WOOL", "SILK", "COTTON", "LEATHER", "METAL"];

  // Filter Logic
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Category Filter
      const matchesCategory =
        selectedCategory === "ALL" ||
        p.categories.some((cat) => cat.toLowerCase() === selectedCategory.toLowerCase());

      // Size Filter
      const matchesSize =
        filterSize === "ALL" || p.sizes.includes(filterSize);

      // Color Filter
      const matchesColor =
        filterColor === "ALL" || p.color.toUpperCase() === filterColor.toUpperCase();

      // Fabric Filter
      const matchesFabric =
        filterFabric === "ALL" || p.fabric.toUpperCase() === filterFabric.toUpperCase();

      // Search Filter
      const matchesSearch =
        searchQuery.trim() === "" ||
        p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesCategory && matchesSize && matchesColor && matchesFabric && matchesSearch;
    });
  }, [selectedCategory, filterSize, filterColor, filterFabric, searchQuery]);

  const visibleProducts = useMemo(() => {
    return filteredProducts.slice(0, visibleCount);
  }, [filteredProducts, visibleCount]);

  const handleToggleWishlist = (e: React.MouseEvent, product: Product) => {
    e.stopPropagation();
    onToggleWishlist(product);
  };

  const toggleDropdown = (type: "size" | "color" | "fabric") => {
    if (activeDropdown === type) {
      setActiveDropdown(null);
    } else {
      setActiveDropdown(type);
    }
  };

  return (
    <div className="pb-24 font-body max-w-7xl mx-auto px-6" id="shop-view">
      {/* Editorial Header */}
      <section className="mb-12 pt-6">
        <p className="font-label text-[10px] uppercase tracking-[0.25em] text-outline mb-4">
          Collection 004 / L'Essence
        </p>
        <h2 className="font-headline text-4xl sm:text-6xl max-w-2xl leading-tight font-light select-none">
          Quiet Elegance <br /> in Monochrome.
        </h2>
      </section>

      {/* Action / Search & Categories Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12 pb-6 border-b border-outline-variant/10">
        {/* Categories Pills */}
        <div className="flex flex-wrap gap-2 overflow-x-auto hide-scrollbar select-none">
          {["ALL", "Dresses", "Outerwear", "Tailoring", "Accessories", "Footwear"].map((cat) => (
            <button
              key={cat}
              onClick={() => {
                onSetCategory(cat);
                setVisibleCount(6); // reset pagination
              }}
              className={`px-4 py-2 text-xs font-label uppercase tracking-widest border transition-all cursor-pointer ${
                selectedCategory === cat
                  ? "bg-primary text-on-primary border-primary"
                  : "bg-surface text-outline border-outline-variant/35 hover:border-outline hover:text-primary"
              }`}
              id={`filter-pill-${cat.toLowerCase()}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search bar */}
        <div className="relative w-full md:w-80">
          <input
            type="text"
            placeholder="Search our anthology..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-surface border-b border-outline-variant/40 py-2.5 pl-4 pr-10 text-xs font-label uppercase tracking-wider focus:outline-none focus:border-primary placeholder:text-outline/50 transition-colors"
            id="product-search-input"
          />
          <Search className="w-4 h-4 text-outline/50 absolute right-3 top-3.5" />
        </div>
      </div>

      {/* Asymmetric Product Grid */}
      {visibleProducts.length === 0 ? (
        <div className="py-24 text-center space-y-4">
          <p className="font-headline text-2xl italic">No elements found</p>
          <p className="text-xs text-outline tracking-wider max-w-sm mx-auto">
            Try resetting your active filters or clear search keywords to browse our full curation.
          </p>
          <button
            onClick={() => {
              onSetCategory("ALL");
              onSetSize("ALL");
              onSetColor("ALL");
              onSetFabric("ALL");
              setSearchQuery("");
            }}
            className="px-8 py-3 bg-primary text-on-primary font-label text-xs uppercase tracking-widest hover:bg-primary-fixed transition-colors cursor-pointer"
            id="reset-all-filters-btn"
          >
            Clear Curation Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-y-20 md:gap-x-12 select-none">
          {visibleProducts.map((product, idx) => {
            const isFav = wishlistIds.includes(product.id);

            // Establish asymmetrical layouts based on indices
            let colSpanClass = "md:col-span-6";
            let aspectClass = "aspect-[4/5]";
            let extraMarginClass = "";

            if (idx % 6 === 0) {
              // Item 1: Wide Portrait col-span-7
              colSpanClass = "md:col-span-7";
              aspectClass = "aspect-[4/5]";
            } else if (idx % 6 === 1) {
              // Item 2: Square Detail col-span-5 offset top
              colSpanClass = "md:col-span-5 md:mt-24";
              aspectClass = "aspect-square";
            } else if (idx % 6 === 2) {
              // Item 3: Tall Vertical col-span-4
              colSpanClass = "md:col-span-4";
              aspectClass = "aspect-[2/3]";
            } else if (idx % 6 === 3) {
              // Item 4: Wide Landscape col-span-8 offset top
              colSpanClass = "md:col-span-8 md:mt-16";
              aspectClass = "aspect-[16/9]";
            } else if (idx % 6 === 4) {
              // Item 5: Small Detail col-span-5
              colSpanClass = "md:col-span-5";
              aspectClass = "aspect-square";
            } else if (idx % 6 === 5) {
              // Item 6: Editorial Frame col-span-7
              colSpanClass = "md:col-span-7";
              aspectClass = "aspect-[4/3]";
            }

            return (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                onClick={() => onNavigateToProduct(product.id)}
                className={`${colSpanClass} ${extraMarginClass} group cursor-pointer`}
                id={`product-card-${product.id}`}
              >
                {/* Product Image Frame */}
                <div className="relative bg-surface-container-lowest overflow-hidden border border-outline-variant/10">
                  <img
                    alt={product.title}
                    className={`w-full ${aspectClass} object-cover grayscale transition-transform duration-700 ease-in-out group-hover:scale-105 group-hover:grayscale-0`}
                    src={product.mainImage}
                    referrerPolicy="no-referrer"
                  />

                  {/* Dark transparent soft hover overlay */}
                  <div className="absolute inset-0 bg-black/5 opacity-100 group-hover:opacity-0 transition-opacity duration-500" />

                  {/* Heart Wishlist Overlay Button */}
                  <button
                    onClick={(e) => handleToggleWishlist(e, product)}
                    className="absolute top-6 right-6 w-10 h-10 rounded-full flex items-center justify-center bg-surface-container-lowest/80 backdrop-blur-sm shadow-sm hover:scale-110 active:scale-95 transition-all cursor-pointer z-10"
                    aria-label={isFav ? "Remove from Wishlist" : "Add to Wishlist"}
                    id={`fav-btn-${product.id}`}
                  >
                    <Heart
                      className={`w-5 h-5 transition-colors ${
                        isFav
                          ? "fill-error text-error"
                          : "text-primary hover:text-error"
                      }`}
                    />
                  </button>

                  {/* Size quick indicator hover overlay */}
                  <div className="absolute bottom-4 left-4 bg-surface-container-lowest/90 px-2 py-1 text-[8px] font-label uppercase tracking-widest text-outline border border-outline-variant/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    Sizes: {product.sizes.join(", ")}
                  </div>
                </div>

                {/* Info Bar */}
                <div className="mt-6 flex justify-between items-start">
                  <div>
                    <h3 className="font-headline text-xl group-hover:underline transition-all">
                      {product.title}
                    </h3>
                    <p className="font-label text-xs uppercase tracking-widest text-outline mt-1 font-medium">
                      {product.subtitle}
                    </p>
                  </div>
                  <span className="font-body text-base font-medium text-primary">
                    ${product.price.toLocaleString()}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Load More Button */}
      {filteredProducts.length > visibleCount && (
        <div className="mt-32 flex justify-center">
          <button
            onClick={() => setVisibleCount((prev) => prev + 6)}
            className="px-12 py-5 bg-primary text-on-primary font-label text-xs uppercase tracking-[0.3em] hover:bg-primary-fixed active:scale-95 transition-all cursor-pointer flex items-center gap-2 group"
            id="discover-more-btn"
          >
            <span>DISCOVER MORE</span>
            <RefreshCw className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-500" />
          </button>
        </div>
      )}

      {/* FLOATING ACTION BUTTON (Filter Panel Trigger) */}
      <div className="fixed bottom-24 right-6 z-30">
        <button
          onClick={() => setIsFilterPanelOpen(true)}
          className="bg-primary text-on-primary w-14 h-14 rounded-full shadow-2xl flex items-center justify-center hover:scale-110 active:scale-95 transition-all cursor-pointer"
          aria-label="Open filter settings"
          id="fab-filter-trigger"
        >
          <Filter className="w-5 h-5 stroke-[2]" />
        </button>
      </div>

      {/* STICKY SLEEK FILTER MENU ABOVE BOTTOM NAV */}
      <div className="fixed bottom-20 left-0 right-0 z-30 bg-surface-container-lowest/95 backdrop-blur-md border-t border-b border-outline-variant/15 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-6 overflow-x-auto hide-scrollbar w-full sm:w-auto">
            {/* Quick Size Dropdown Trigger */}
            <div className="relative">
              <button
                onClick={() => toggleDropdown("size")}
                className="flex items-center space-x-2 cursor-pointer font-label text-xs text-outline hover:text-primary transition-colors"
                id="filter-dropdown-size-btn"
              >
                <span className="text-[10px] uppercase tracking-widest">Size:</span>
                <span className="font-bold text-primary">{filterSize}</span>
                <span className="text-[10px] opacity-75">▼</span>
              </button>
              {activeDropdown === "size" && (
                <div className="absolute bottom-8 left-0 mb-2 bg-surface border border-outline-variant/30 shadow-lg p-2 min-w-[120px] z-50">
                  {sizesList.map((sz) => (
                    <button
                      key={sz}
                      onClick={() => {
                        onSetSize(sz);
                        setActiveDropdown(null);
                      }}
                      className="w-full text-left px-3 py-2 text-xs font-label uppercase tracking-wider hover:bg-surface-container-high transition-colors flex items-center justify-between"
                    >
                      <span>{sz}</span>
                      {filterSize === sz && <Check className="w-3 h-3 text-primary" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Color Dropdown Trigger */}
            <div className="relative">
              <button
                onClick={() => toggleDropdown("color")}
                className="flex items-center space-x-2 cursor-pointer font-label text-xs text-outline hover:text-primary transition-colors"
                id="filter-dropdown-color-btn"
              >
                <span className="text-[10px] uppercase tracking-widest">Color:</span>
                {filterColor !== "ALL" && (
                  <span className="w-2.5 h-2.5 bg-black inline-block border border-outline-variant"></span>
                )}
                <span className="font-bold text-primary">{filterColor}</span>
                <span className="text-[10px] opacity-75">▼</span>
              </button>
              {activeDropdown === "color" && (
                <div className="absolute bottom-8 left-0 mb-2 bg-surface border border-outline-variant/30 shadow-lg p-2 min-w-[120px] z-50">
                  {colorsList.map((cl) => (
                    <button
                      key={cl}
                      onClick={() => {
                        onSetColor(cl);
                        setActiveDropdown(null);
                      }}
                      className="w-full text-left px-3 py-2 text-xs font-label uppercase tracking-wider hover:bg-surface-container-high transition-colors flex items-center justify-between"
                    >
                      <span>{cl}</span>
                      {filterColor === cl && <Check className="w-3 h-3 text-primary" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Fabric Dropdown Trigger */}
            <div className="relative">
              <button
                onClick={() => toggleDropdown("fabric")}
                className="flex items-center space-x-2 cursor-pointer font-label text-xs text-outline hover:text-primary transition-colors"
                id="filter-dropdown-fabric-btn"
              >
                <span className="text-[10px] uppercase tracking-widest">Fabric:</span>
                <span className="font-bold text-primary">{filterFabric}</span>
                <span className="text-[10px] opacity-75">▼</span>
              </button>
              {activeDropdown === "fabric" && (
                <div className="absolute bottom-8 left-0 mb-2 bg-surface border border-outline-variant/30 shadow-lg p-2 min-w-[140px] z-50">
                  {fabricsList.map((fb) => (
                    <button
                      key={fb}
                      onClick={() => {
                        onSetFabric(fb);
                        setActiveDropdown(null);
                      }}
                      className="w-full text-left px-3 py-2 text-xs font-label uppercase tracking-wider hover:bg-surface-container-high transition-colors flex items-center justify-between"
                    >
                      <span>{fb}</span>
                      {filterFabric === fb && <Check className="w-3 h-3 text-primary" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="hidden md:block select-none">
            <p className="font-label text-[10px] uppercase tracking-[0.25em] text-outline">
              {filteredProducts.length} items found
            </p>
          </div>
        </div>
      </div>

      {/* FILTER PANEL FULL SCREEN DRAWER */}
      <AnimatePresence>
        {isFilterPanelOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsFilterPanelOpen(false)}
              className="fixed inset-0 bg-black/35 backdrop-blur-sm z-50 cursor-pointer"
            />

            {/* Filter Content Drawer */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 30 }}
              className="fixed right-0 top-0 bottom-0 w-full sm:w-[400px] bg-surface z-50 p-8 flex flex-col justify-between border-l border-outline-variant/10 select-none"
              id="filter-fullscreen-panel"
            >
              <div className="space-y-8">
                <div className="flex justify-between items-center border-b border-outline-variant/15 pb-4">
                  <h3 className="font-headline text-lg tracking-widest uppercase">
                    FILTER ANTHOLOGY
                  </h3>
                  <button
                    onClick={() => setIsFilterPanelOpen(false)}
                    className="font-label text-xs uppercase tracking-widest hover:underline cursor-pointer"
                  >
                    CLOSE
                  </button>
                </div>

                {/* Sizes Filter Selector */}
                <div className="space-y-3">
                  <label className="font-label text-[10px] uppercase tracking-[0.2em] text-outline font-medium">
                    Filter by Size
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {sizesList.map((sz) => (
                      <button
                        key={sz}
                        onClick={() => onSetSize(sz)}
                        className={`py-3 text-xs font-label uppercase tracking-wider border transition-all cursor-pointer ${
                          filterSize === sz
                            ? "bg-primary text-on-primary border-primary"
                            : "bg-surface text-outline border-outline-variant/30 hover:border-primary"
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Colors Filter Selector */}
                <div className="space-y-3">
                  <label className="font-label text-[10px] uppercase tracking-[0.2em] text-outline font-medium">
                    Filter by Color
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {colorsList.map((cl) => (
                      <button
                        key={cl}
                        onClick={() => onSetColor(cl)}
                        className={`px-4 py-2.5 text-xs font-label uppercase tracking-widest border transition-all cursor-pointer ${
                          filterColor === cl
                            ? "bg-primary text-on-primary border-primary"
                            : "bg-surface text-outline border-outline-variant/30 hover:border-primary"
                        }`}
                      >
                        {cl}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Fabrics Filter Selector */}
                <div className="space-y-3">
                  <label className="font-label text-[10px] uppercase tracking-[0.2em] text-outline font-medium">
                    Filter by Fabric
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {fabricsList.map((fb) => (
                      <button
                        key={fb}
                        onClick={() => onSetFabric(fb)}
                        className={`px-4 py-2.5 text-xs font-label uppercase tracking-widest border transition-all cursor-pointer ${
                          filterFabric === fb
                            ? "bg-primary text-on-primary border-primary"
                            : "bg-surface text-outline border-outline-variant/30 hover:border-primary"
                        }`}
                      >
                        {fb}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Apply / Clear Buttons */}
              <div className="space-y-3">
                <button
                  onClick={() => setIsFilterPanelOpen(false)}
                  className="w-full bg-primary text-on-primary py-4 font-label text-xs uppercase tracking-widest hover:bg-primary-fixed transition-colors cursor-pointer"
                >
                  APPLY FILTERS ({filteredProducts.length})
                </button>
                <button
                  onClick={() => {
                    onSetSize("ALL");
                    onSetColor("ALL");
                    onSetFabric("ALL");
                    onSetCategory("ALL");
                  }}
                  className="w-full bg-surface border border-outline-variant/40 text-outline hover:text-primary hover:border-primary py-4 font-label text-xs uppercase tracking-widest transition-all cursor-pointer"
                >
                  CLEAR ALL FILTERS
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
